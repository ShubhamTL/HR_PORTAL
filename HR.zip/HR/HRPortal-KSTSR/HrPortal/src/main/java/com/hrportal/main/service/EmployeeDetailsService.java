package com.hrportal.main.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrportal.main.pojo.EmployeeDetails;
import com.hrportal.main.pojo.RequirementDetails;
import com.hrportal.main.repository.EmployeeDetailsRepository;
import com.hrportal.main.repository.RequirementDetailsRepository;

@Service
public class EmployeeDetailsService implements EmployeeDetailsServiceInterface {

	// private String emailId;
	// private char[] ch;

	@Autowired
	private EmployeeDetailsRepository employeeDetailsRepository;
	@Autowired
	private RequirementDetailsRepository requirementDetailsRepository;

	@Override
	public boolean addEmployeeDetails(EmployeeDetails employeeDetails) {
		// String emailId = employeeDetails.getEmailId();

		// for(int i=0;i<emailId.length();i++) {
		// if(emailId.charAt(i)=='@')
		return employeeDetailsRepository.addEmployeeDetails(employeeDetails);

		// }
		// return false;
	}

	@Override
	public boolean updateEmployeeDetails(EmployeeDetails employeeDetails) {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.updateEmployeeDetails(employeeDetails);
	}

	@Override
	public boolean deleteEmployeeDetails(int employeeId) {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.deleteEmployeeDetails(employeeId);
	}

	@Override
	public EmployeeDetails getEmployeeDetailsByEmployeeId(int employeeId) {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.getEmployeeDetailsByEmployeeId(employeeId);
	}

	@Override
	public List<EmployeeDetails> getAllEmployeeDetails() {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.getAllEmployeeDetails();
	}

	@Override
	public EmployeeDetails getEmployeeDetailsByLoginId(int loginId) {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.getEmployeeDetailsByLoginId(loginId);
	}

	@Override
	public List<EmployeeDetails> getEmployeeOnBench(RequirementDetails requirementDetails) {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.getEmployeeOnBench(requirementDetails);
	}

	@Override
	public boolean updateEmployeeProjectId(EmployeeDetails employeeDetails) {
		boolean result = employeeDetailsRepository.updateEmployeeProjectId(employeeDetails);
		int jobId = employeeDetails.getMgrId();
		int requiredEmployee = requirementDetailsRepository.getRequiredNoOfEmployeesByJobId(jobId);
		requiredEmployee = requiredEmployee - 1;
		RequirementDetails requirementDetails = requirementDetailsRepository.getRequirmentDetailsByJobId(jobId);
		
		requirementDetails.setRequiredNoOfEmployees(requiredEmployee);
		boolean updateRequiredNumberOfEmployee = requirementDetailsRepository
				.updateRequirmentDetails(requirementDetails);

		if (result && updateRequiredNumberOfEmployee) {
			return result;

		}
		return false;

	}

}
