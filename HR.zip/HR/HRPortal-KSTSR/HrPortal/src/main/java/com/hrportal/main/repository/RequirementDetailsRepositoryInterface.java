package com.hrportal.main.repository;

import java.util.List;

import com.hrportal.main.pojo.EmployeeDetails;
import com.hrportal.main.pojo.RequirementDetails;

public interface RequirementDetailsRepositoryInterface {


	public boolean addRequirmentDetails(RequirementDetails requirementDetails);
	public boolean updateRequirmentDetails(RequirementDetails requirementDetails);
	public boolean deleteRequirmentDetailsDetails(int jobId);
	public RequirementDetails getRequirmentDetailsByJobId(int jobId);
	public  List<RequirementDetails> getAllRequirmentDetails();
	public List<RequirementDetails> getSingleRequestByProjectId(int projectId);
	public int getRequiredNoOfEmployeesByJobId(int jobId);
	public boolean updateRequirementdetailsStatus(RequirementDetails requirementDetails);

	public boolean updateRequirementdetailsStatusToAccepted(RequirementDetails requirementDetails);
	
	public List<RequirementDetails> getRequirementDetailsByAcceptedStatus ();
	public List<RequirementDetails> getRequirementDetailsBySendToHrStatusStatus ();
	public List<RequirementDetails> getRequirementDetailsByInProcessStatus ();
	
}
