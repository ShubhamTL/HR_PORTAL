package com.hrportal.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.hrportal.main.pojo.InterviewDetails;
import com.hrportal.main.repository.CandidateDetailsRepository;
import com.hrportal.main.repository.CandidateDetailsRepositoryInterface;
import com.hrportal.main.repository.InterviewDetailsRepositoryInterface;
@Service
public class InterviewDetailsService implements InterviewDetailsServiceInterface{
	@Autowired
	private InterviewDetailsRepositoryInterface interviewDetailsRepository; 
	@Autowired
	private CandidateDetailsRepositoryInterface candidateDetailsRepository;

	@Override
	public boolean addInterviewDetails(InterviewDetails interviewDetails) {
		boolean candidateDetails = candidateDetailsRepository.updateCandidateApplicationStatusByCandidateId(interviewDetails.getInterviewStatus(), interviewDetails.getCandidateDetails().getCandidateId());

		return interviewDetailsRepository.addInterviewDetails(interviewDetails);
		
	}

	@Override
	public boolean updateInterviewDetails(InterviewDetails interviewDetails) {
		// TODO Auto-generated method stub
		return interviewDetailsRepository.updateInterviewDetails(interviewDetails);
	}

	@Override
	public boolean deleteInterviewDetails(int interviewId) {
		// TODO Auto-generated method stub
		return interviewDetailsRepository.deleteInterviewDetails(interviewId);
	}

	@Override
	public InterviewDetails getInterviewDetailsByinterviewId(int interviewId) {
		// TODO Auto-generated method stub
		return interviewDetailsRepository.getInterviewDetailsByinterviewId(interviewId);
	}

	@Override
	public List<InterviewDetails> getAllInterviewDetails() {
		// TODO Auto-generated method stub
		return interviewDetailsRepository.getAllInterviewDetails();
	}

	@Override
	public List<InterviewDetails> getInterviewDetailsBySelectedStatus() {
		// TODO Auto-generated method stub
		return interviewDetailsRepository.getInterviewDetailsBySelectedStatus();
	}

	@Override
	public List<InterviewDetails> getInterviewDetailsByRejectedStatus() {
		// TODO Auto-generated method stub
		return interviewDetailsRepository.getInterviewDetailsByRejectedStatus();
	}


	
	
	//For EmailSending
	 @Autowired 
	 private JavaMailSender javaMailSender;
	  @Value("${spring.mail.username}") private String sender;


@Override
	public boolean sendMailByInterviewStatus(InterviewDetails interviewDetails) {
		
	    // Method 1
	    // To send a simple email
  		
	 
	        // Try block to check for exceptions
	        try {
	 
	            // Creating a simple mail message
	            SimpleMailMessage mailMessage= new SimpleMailMessage();
	 
	            // Setting up necessary details
	            mailMessage.setFrom(sender);
	            mailMessage.setTo(interviewDetails.getCandidateDetails().getEmailId());
	            mailMessage.setSubject("Interview Result");
	      
	            if(interviewDetails.getInterviewStatus().equalsIgnoreCase("SELECTED")){
	            // Sending the mail
	            	mailMessage.setText("Thanks for applying to work at our organization. our focus has always been on finding the best people and "
	            			+ "developing them into the technology leaders of tomorrow."
	            			+ "	You have been selected for this position"
	            			+ "	Thanks again for your interest");
	            javaMailSender.send(mailMessage);
	            }
	            if(interviewDetails.getInterviewStatus().equalsIgnoreCase("REJECTED")) {
	             	mailMessage.setText("Thanks for applying to work at our organization. our focus has always been on finding the best people and "
	             			+ "developing them into the technology leaders of tomorrow."
	             			+ "We've had very competitive pool of cadidates and unfortunately, you hav not been selected for this position"
	             			+ "Thanks again for your interest");
	            javaMailSender.send(mailMessage);
	            }
	            return true;
	        }
	 
	        // Catch block to handle the exceptions
	        catch (Exception e) {
	            return false;
	        }
	    

}
}
