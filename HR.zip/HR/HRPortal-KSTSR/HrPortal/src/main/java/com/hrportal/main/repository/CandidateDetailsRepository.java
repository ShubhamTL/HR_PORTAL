package com.hrportal.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.hrportal.main.pojo.CandidateDetails;
import com.hrportal.main.pojo.ProjectMaster;

@Repository
public class CandidateDetailsRepository implements CandidateDetailsRepositoryInterface {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	private int resultCount;

	@Autowired
	private CandidateDetailsRowMapper candidateDetailsRowMapper;

	private static String SELECT_ALL_CANDIDATE_DETAILS = "SELECT * FROM CANDIDATE_DETAILS ";
	private static String SELECT_SINGLE_CANDIDATE_DETAILS = "SELECT * FROM CANDIDATE_DETAILS WHERE CANDIDATE_ID = ?";

	private static String INSERT_CANDIDATE_DETAILS = "INSERT INTO CANDIDATE_DETAILS(CANDIDATE_ID,JOB_ID,FIRST_NAME"
			+ ",LAST_NAME,EMAIL_ID,CONTACT_NO,DATE_OF_BIRTH,QUALIFICATION,EXPERIENCE,PRIMARY_SKILL_1,PRIMARY_SKILL_2,"
			+ "PRIMARY_SKILL_3,APPLICATION_STATUS,FILE_ID) VALUES(SEQ4_CANDIDATE_DETAILS.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	private static String UPDATE_CANDIDATE_DETAILS = "UPDATE CANDIDATE_DETAILS SET JOB_ID = ?,FIRST_NAME = ?,"
			+ "LAST_NAME = ?,EMAIL_ID = ?,CONTACT_NO = ?,DATE_OF_BIRTH = ?,QUALIFICATION = ?,EXPERIENCE = ?,PRIMARY_SKILL_1 = ?"
			+ ",PRIMARY_SKILL_2 = ?,PRIMARY_SKILL_3 = ?,APPLICATION_STATUS = ?,FILE_ID = ? WHERE CANDIDATE_ID=? ";
	private static String DELETE_CANDIDATE_DETAILS = "DELETE CANDIDATE_DETAILS WHERE CANDIDATE_ID = ?";
	private static String UPDATE_CANDIDATE_DETAILS_APPLICATION_STATUS = "UPDATE CANDIDATE_DETAILS SET APPLICATION_STATUS='SEND_TO_INTERVIEWER' WHERE CANDIDATE_ID=?";

	private static String SELECT_CANDIDATE_DETAILS_BY_SEND_TO_INTERVIEWER_STATUS = "SELECT * FROM CANDIDATE_DETAILS WHERE APPLICATION_STATUS='SEND TO INTERVIEWER'";
	private static String UPDATE_CANDIDATE_DETAILS_BY_INTERVIEWER = "UPDATE CANDIDATE_DETAILS SET APPLICATION_STATUS=? WHERE CANDIDATE_ID=? ";

	private static String SELECT_CANDIDATE_DETAILS_BY_SELECTED_STATUS = "SELECT * FROM CANDIDATE_DETAILS WHERE APPLICATION_STATUS='SELECTED'";

	private static String SELECT_CANDIDATE_DETAILS_BY_REJECTED_STATUS = "SELECT * FROM CANDIDATE_DETAILS WHERE APPLICATION_STATUS='REJECTED'";

	private static String SELECT_CANDIDATE_DETAILS_BY_IN_PROCESS_STATUS = "SELECT * FROM CANDIDATE_DETAILS WHERE APPLICATION_STATUS='IN_PROCESS'";

	@Override
	public boolean addCandidateDetails(CandidateDetails candidateDetails) {
		Object[] args = { candidateDetails.getRequirementDetails().getJobId(),
				candidateDetails.getFirstName(), candidateDetails.getLastName(), candidateDetails.getEmailId(),
				candidateDetails.getContactNo(), candidateDetails.getDateOfBirth(), candidateDetails.getQualification(),
				candidateDetails.getExperience(), candidateDetails.getPrimarySkill1(),
				candidateDetails.getPrimarySkill2(), candidateDetails.getPrimarySkill3(),
				candidateDetails.getApplicationStatus(), candidateDetails.getFileId() };
		resultCount = jdbcTemplate.update(INSERT_CANDIDATE_DETAILS, args);
		if (resultCount > 0)
			return true;
		else
			return false;
	}

	@Override
	public boolean updateCandidateDetails(CandidateDetails candidateDetails) {
		Object[] args = { candidateDetails.getRequirementDetails().getJobId(),
				candidateDetails.getFirstName(), candidateDetails.getLastName(), candidateDetails.getEmailId(),
				candidateDetails.getContactNo(), candidateDetails.getDateOfBirth(), candidateDetails.getQualification(),
				candidateDetails.getExperience(), candidateDetails.getPrimarySkill1(),
				candidateDetails.getPrimarySkill2(), candidateDetails.getPrimarySkill3(),
				candidateDetails.getApplicationStatus(), candidateDetails.getFileId(),
				candidateDetails.getCandidateId() };
		resultCount = jdbcTemplate.update(UPDATE_CANDIDATE_DETAILS, args);
		if (resultCount > 0)
			return true;
		else
			return false;
	}

	@Override
	public boolean deleteCandidateDetailsDetails(int candidateId) {
		Object[] args = { candidateId };
		resultCount = jdbcTemplate.update(DELETE_CANDIDATE_DETAILS, args);
		if (resultCount > 0)
			return true;
		else
			return false;

	}

	@Override
	public CandidateDetails getCandidateDetailsByCandidateId(int candidateId) {
		Object[] args = { candidateId };
		CandidateDetails candidateDetails = jdbcTemplate.queryForObject(SELECT_SINGLE_CANDIDATE_DETAILS,
				candidateDetailsRowMapper, args);
		return candidateDetails;
	}

	@Override
	public List<CandidateDetails> getAllCandidateDetails() {
		List<CandidateDetails> allCandidateDetails = jdbcTemplate.query(SELECT_ALL_CANDIDATE_DETAILS,
				candidateDetailsRowMapper);
		return allCandidateDetails;
	}

	@Override
	public boolean updateCandidateDetailsStatusById(CandidateDetails candidateDetails) {
		Object[] args = {  candidateDetails.getCandidateId() };
		resultCount = jdbcTemplate.update(UPDATE_CANDIDATE_DETAILS_APPLICATION_STATUS, args);
		if (resultCount > 0)
			return true;
		else
			return false;
	}

	@Override
	public List<CandidateDetails> getCandidateDetailsBySendToInterviewerStatus() {
		List<CandidateDetails> candidateBySendToInterviewerStatus = jdbcTemplate
				.query(SELECT_CANDIDATE_DETAILS_BY_SEND_TO_INTERVIEWER_STATUS, candidateDetailsRowMapper);
		return candidateBySendToInterviewerStatus;
	}

	@Override
	public boolean updateCandidateApplicationStatusByCandidateId(String applicationStatus, int candidateId) {
		Object[] args = { applicationStatus, candidateId };
		resultCount = jdbcTemplate.update(UPDATE_CANDIDATE_DETAILS_BY_INTERVIEWER, args);
		if (resultCount > 0)
			return true;
		else
			return false;
	}
	
	@Override
	public List<CandidateDetails> getCandidateDetailsBySelectedStatus() {
		List<CandidateDetails> candidateBySelectedStatus=jdbcTemplate.query(SELECT_CANDIDATE_DETAILS_BY_SELECTED_STATUS, candidateDetailsRowMapper);
		return candidateBySelectedStatus;
	}
	
	@Override
	public List<CandidateDetails> getCandidateDetailsByRejectedStatus() {
		List<CandidateDetails> candidateByRejectedStatus=jdbcTemplate.query(SELECT_CANDIDATE_DETAILS_BY_REJECTED_STATUS, candidateDetailsRowMapper);
		return candidateByRejectedStatus;
	}
	
	@Override
	public List<CandidateDetails> getCandidateDetailsByInProcessStatus() {
		List<CandidateDetails> candidateByInProcessStatus=jdbcTemplate.query(SELECT_CANDIDATE_DETAILS_BY_IN_PROCESS_STATUS, candidateDetailsRowMapper);
		return candidateByInProcessStatus;
	}
}
