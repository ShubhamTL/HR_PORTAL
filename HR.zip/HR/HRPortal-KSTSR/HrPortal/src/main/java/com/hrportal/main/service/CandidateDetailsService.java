package com.hrportal.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrportal.main.pojo.CandidateDetails;
import com.hrportal.main.pojo.EmployeeDetails;
import com.hrportal.main.pojo.LoginDetails;
import com.hrportal.main.pojo.RequirementDetails;
import com.hrportal.main.repository.CandidateDetailsRepository;
import com.hrportal.main.repository.RequirementDetailsRepositoryInterface;

@Service
public class CandidateDetailsService implements CandidateDetailsServiceInterface {

	@Autowired
	private CandidateDetailsRepository candidateDetailsRepository;
	@Override
	public boolean addCandidateDetails(CandidateDetails candidateDetails) {
		// TODO Auto-generated method stub
		return candidateDetailsRepository.addCandidateDetails(candidateDetails);
	}

	@Override
	public boolean updateCandidateDetails(CandidateDetails candidateDetails) {
		// TODO Auto-generated method stub
		return candidateDetailsRepository.updateCandidateDetails(candidateDetails);
	}

	@Override
	public boolean deleteCandidateDetailsDetails(int candidateId) {
		// TODO Auto-generated method stub
		return candidateDetailsRepository.deleteCandidateDetailsDetails(candidateId);
	}

	@Override
	public CandidateDetails getCandidateDetailsByCandidateId(int candidateId) {
		// TODO Auto-generated method stub
		return candidateDetailsRepository.getCandidateDetailsByCandidateId(candidateId);
	}


	@Override
	public List<CandidateDetails> getAllCandidateDetails() {
		// TODO Auto-generated method stub
		return candidateDetailsRepository.getAllCandidateDetails();
	}

	@Override
	public boolean updateCandidateDetailsStatusById(CandidateDetails candidateDetails) {
		// TODO Auto-generated method stub
		return candidateDetailsRepository.updateCandidateDetailsStatusById(candidateDetails)	;
	}
	
	@Override
	public List<CandidateDetails> getCandidateDetailsBySendToInterviewerStatus() {
		// TODO Auto-generated method stub
		return candidateDetailsRepository.getCandidateDetailsBySendToInterviewerStatus();
	}
	
	@Override
	public boolean updateCandidateApplicationStatusByCandidateId(String applicationStatus,int candidateId) {
		// TODO Auto-generated method stub
		return candidateDetailsRepository.updateCandidateApplicationStatusByCandidateId(applicationStatus, candidateId);
	}

	@Override
	public List<CandidateDetails> getCandidateDetailsBySelectedStatus() {
		// TODO Auto-generated method stub
		return candidateDetailsRepository.getCandidateDetailsBySelectedStatus();
	}

	@Override
	public List<CandidateDetails> getCandidateDetailsByRejectedStatus() {
		// TODO Auto-generated method stub
		return candidateDetailsRepository.getCandidateDetailsByRejectedStatus();
	}

	@Override
	public List<CandidateDetails> getCandidateDetailsByInProcessStatus() {
		// TODO Auto-generated method stub
		return candidateDetailsRepository.getCandidateDetailsByInProcessStatus();
	}

}
